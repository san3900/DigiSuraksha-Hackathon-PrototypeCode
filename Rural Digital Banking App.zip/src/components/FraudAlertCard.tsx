import { AlertTriangle, ShieldAlert, Info, CheckCircle2 } from 'lucide-react';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { FraudAlert } from '../types';

interface FraudAlertCardProps {
  alert: FraudAlert;
}

export function FraudAlertCard({ alert }: FraudAlertCardProps) {
  const severityConfig = {
    low: { icon: Info, color: 'text-blue-600', bg: 'bg-blue-500/10', badge: 'default' as const },
    medium: { icon: AlertTriangle, color: 'text-yellow-600', bg: 'bg-yellow-500/10', badge: 'secondary' as const },
    high: { icon: AlertTriangle, color: 'text-orange-600', bg: 'bg-orange-500/10', badge: 'destructive' as const },
    critical: { icon: ShieldAlert, color: 'text-red-600', bg: 'bg-red-500/10', badge: 'destructive' as const },
  };

  const config = severityConfig[alert.severity];
  const Icon = config.icon;

  return (
    <Card className={`p-3 sm:p-4 ${alert.resolved ? 'opacity-60' : ''}`}>
      <div className="flex items-start gap-2 sm:gap-3">
        <div className={`w-8 h-8 sm:w-10 sm:h-10 rounded-full flex items-center justify-center flex-shrink-0 ${config.bg}`}>
          <Icon className={`w-4 h-4 sm:w-5 sm:h-5 ${config.color}`} />
        </div>
        
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-1.5 sm:gap-2 flex-wrap">
            <Badge variant={config.badge} className="text-[10px] sm:text-xs">{alert.severity.toUpperCase()}</Badge>
            {alert.resolved && (
              <div className="flex items-center gap-1 text-green-600 text-xs sm:text-sm">
                <CheckCircle2 className="w-3 h-3 sm:w-4 sm:h-4" />
                <span>Resolved</span>
              </div>
            )}
          </div>
          <p className="mt-1.5 sm:mt-2 text-sm sm:text-base">{alert.message}</p>
          <p className="text-muted-foreground mt-1 text-xs sm:text-sm">
            {new Date(alert.timestamp).toLocaleDateString('en-IN')} •{' '}
            {new Date(alert.timestamp).toLocaleTimeString('en-IN', { 
              hour: '2-digit', 
              minute: '2-digit' 
            })}
          </p>
        </div>
      </div>
    </Card>
  );
}