import { useState } from 'react';
import { 
  Home, 
  CreditCard, 
  Shield, 
  User, 
  Wallet,
  TrendingUp,
  Send,
  Download,
  QrCode,
  WifiOff,
  Globe,
  ChevronRight,
  Phone,
  Zap,
  ShoppingCart,
  Film,
  Smartphone,
  DollarSign,
  Receipt,
  History,
  Settings,
  Bell,
  HelpCircle,
  FileText
} from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Progress } from './ui/progress';
import { TransactionCard } from './TransactionCard';
import { FraudAlertCard } from './FraudAlertCard';
import { QuickAction } from './QuickAction';
import { StatCard } from './StatCard';
import { LanguageSelector } from './LanguageSelector';
import { AlertBanner } from './AlertBanner';
import { Language } from '../types';
import { t } from '../utils/translations';
import { mockUser, mockTransactions, mockFraudAlerts } from '../utils/mockData';

interface DashboardProps {
  language: Language;
  onLanguageChange: (language: Language) => void;
  onLogout: () => void;
}

export function Dashboard({ language, onLanguageChange, onLogout }: DashboardProps) {
  const [activeTab, setActiveTab] = useState('home');
  const [offlineMode, setOfflineMode] = useState(false);

  const unresolvedAlerts = mockFraudAlerts.filter(a => !a.resolved);

  return (
    <div className="min-h-screen flex flex-col bg-background safe-area-inset">
      {/* Header */}
      <div className="sticky top-0 z-10 bg-background border-b safe-area-inset-top">
        <div className="p-3 sm:p-4 flex items-center justify-between gap-2">
          <div className="flex items-center gap-2 sm:gap-3 min-w-0">
            <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-full bg-gradient-to-br from-blue-600 to-purple-600 flex items-center justify-center flex-shrink-0">
              <Shield className="w-4 h-4 sm:w-6 sm:h-6 text-white" />
            </div>
            <div className="min-w-0">
              <h3 className="truncate text-sm sm:text-base">{mockUser.name}</h3>
              <p className="text-muted-foreground text-xs sm:text-sm">{mockUser.accountNumber}</p>
            </div>
          </div>
          <div className="flex items-center gap-1 sm:gap-2 flex-shrink-0">
            {offlineMode && (
              <Badge variant="secondary" className="gap-1 hidden sm:flex">
                <WifiOff className="w-3 h-3" />
                {t('offlineMode', language)}
              </Badge>
            )}
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8 sm:h-10 sm:w-10"
              onClick={() => setOfflineMode(!offlineMode)}
            >
              <WifiOff className={`w-4 h-4 sm:w-5 sm:h-5 ${offlineMode ? 'text-orange-600' : ''}`} />
            </Button>
            <div className="hidden sm:block">
              <LanguageSelector currentLanguage={language} onLanguageChange={onLanguageChange} />
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-auto custom-scrollbar">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="h-full flex flex-col">
          <div className="flex-1 overflow-auto pb-20 custom-scrollbar">
            {/* Home Tab */}
            <TabsContent value="home" className="m-0 p-3 sm:p-4 space-y-4 sm:space-y-6">
              {/* Offline Warning */}
              {offlineMode && (
                <AlertBanner 
                  message="You are in offline mode. Transactions will sync when connection is restored."
                  type="warning"
                  dismissible={false}
                />
              )}

              {/* Balance Card */}
              <Card className="p-4 sm:p-6 bg-gradient-to-br from-blue-600 to-purple-600 text-white border-0">
                <p className="opacity-90 mb-1 sm:mb-2 text-sm sm:text-base">{t('balance', language)}</p>
                <h1 className="text-3xl sm:text-4xl mb-3 sm:mb-4">₹{mockUser.balance.toLocaleString('en-IN')}</h1>
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <div className="flex items-center gap-2">
                    <Shield className="w-3 h-3 sm:w-4 sm:h-4" />
                    <span className="text-sm sm:text-base">{t('trustScore', language)}: {mockUser.trustScore}%</span>
                  </div>
                  <Badge variant="secondary" className="bg-white/20 text-white border-0 text-xs sm:text-sm">
                    {t('deviceTrusted', language)} ✓
                  </Badge>
                </div>
              </Card>

              {/* Security Stats */}
              <div className="grid grid-cols-2 gap-3 sm:gap-4">
                <StatCard
                  icon={TrendingUp}
                  label={t('trustScore', language)}
                  value={`${mockUser.trustScore}%`}
                  color="#10b981"
                  sublabel="Excellent"
                />
                <StatCard
                  icon={Shield}
                  label="Active Protection"
                  value="On"
                  color="#3b82f6"
                  sublabel="All systems secured"
                />
              </div>

              {/* Quick Actions - Expanded */}
              <Card className="p-4 sm:p-6">
                <h3 className="mb-3 sm:mb-4">Quick Actions</h3>
                <div className="grid grid-cols-3 sm:grid-cols-4 lg:grid-cols-6 gap-2 sm:gap-3">
                  <QuickAction icon={Send} label={t('sendMoney', language)} color="#3b82f6" onClick={() => {}} />
                  <QuickAction icon={Download} label={t('receiveMoney', language)} color="#10b981" onClick={() => {}} />
                  <QuickAction icon={QrCode} label={t('scanQR', language)} color="#f59e0b" onClick={() => {}} />
                  <QuickAction icon={Phone} label="Recharge" color="#8b5cf6" onClick={() => {}} />
                  <QuickAction icon={Zap} label="Bills" color="#ec4899" onClick={() => {}} />
                  <QuickAction icon={ShoppingCart} label="Shop" color="#14b8a6" onClick={() => {}} />
                  <QuickAction icon={Film} label="Movies" color="#f43f5e" onClick={() => {}} />
                  <QuickAction icon={Smartphone} label="DTH" color="#06b6d4" onClick={() => {}} />
                  <QuickAction icon={DollarSign} label="Loan" color="#84cc16" onClick={() => {}} />
                  <QuickAction icon={Receipt} label="Insurance" color="#a855f7" onClick={() => {}} />
                  <QuickAction icon={Wallet} label="Wallet" color="#f97316" onClick={() => {}} />
                  <QuickAction icon={History} label="History" color="#6366f1" onClick={() => {}} />
                </div>
              </Card>

              {/* Additional Services */}
              <Card className="p-4 sm:p-6">
                <h3 className="mb-3 sm:mb-4">Bank Services</h3>
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2 sm:gap-3">
                  <button className="flex items-center gap-2 sm:gap-3 p-3 sm:p-4 rounded-lg bg-accent hover:bg-accent/80 transition-all active:scale-95 text-left min-h-[60px] sm:min-h-[72px]">
                    <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-blue-500/20 flex items-center justify-center flex-shrink-0">
                      <FileText className="w-5 h-5 sm:w-6 sm:h-6 text-blue-600" />
                    </div>
                    <div className="text-left min-w-0 flex-1">
                      <p className="text-xs sm:text-sm truncate">Statements</p>
                    </div>
                  </button>
                  <button className="flex items-center gap-2 sm:gap-3 p-3 sm:p-4 rounded-lg bg-accent hover:bg-accent/80 transition-all active:scale-95 text-left min-h-[60px] sm:min-h-[72px]">
                    <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-green-500/20 flex items-center justify-center flex-shrink-0">
                      <CreditCard className="w-5 h-5 sm:w-6 sm:h-6 text-green-600" />
                    </div>
                    <div className="text-left min-w-0 flex-1">
                      <p className="text-xs sm:text-sm truncate">Cards</p>
                    </div>
                  </button>
                  <button className="flex items-center gap-2 sm:gap-3 p-3 sm:p-4 rounded-lg bg-accent hover:bg-accent/80 transition-all active:scale-95 text-left min-h-[60px] sm:min-h-[72px]">
                    <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-purple-500/20 flex items-center justify-center flex-shrink-0">
                      <Settings className="w-5 h-5 sm:w-6 sm:h-6 text-purple-600" />
                    </div>
                    <div className="text-left min-w-0 flex-1">
                      <p className="text-xs sm:text-sm truncate">Settings</p>
                    </div>
                  </button>
                  <button className="flex items-center gap-2 sm:gap-3 p-3 sm:p-4 rounded-lg bg-accent hover:bg-accent/80 transition-all active:scale-95 text-left min-h-[60px] sm:min-h-[72px]">
                    <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-orange-500/20 flex items-center justify-center flex-shrink-0">
                      <HelpCircle className="w-5 h-5 sm:w-6 sm:h-6 text-orange-600" />
                    </div>
                    <div className="text-left min-w-0 flex-1">
                      <p className="text-xs sm:text-sm truncate">Help</p>
                    </div>
                  </button>
                </div>
              </Card>

              {/* Fraud Alerts */}
              {unresolvedAlerts.length > 0 && (
                <div className="space-y-3">
                  <div className="flex items-center justify-between gap-2">
                    <h3 className="text-base sm:text-lg">{t('fraudAlerts', language)}</h3>
                    <Button 
                      variant="link" 
                      onClick={() => setActiveTab('security')} 
                      className="text-xs sm:text-sm p-0 h-auto flex-shrink-0"
                    >
                      {t('viewAll', language)} <ChevronRight className="w-3 h-3 sm:w-4 sm:h-4 ml-1" />
                    </Button>
                  </div>
                  {unresolvedAlerts.slice(0, 2).map(alert => (
                    <FraudAlertCard key={alert.id} alert={alert} />
                  ))}
                </div>
              )}

              {/* Recent Transactions */}
              <div className="space-y-3">
                <div className="flex items-center justify-between gap-2">
                  <h3 className="text-base sm:text-lg">{t('recentTransactions', language)}</h3>
                  <Button 
                    variant="link" 
                    onClick={() => setActiveTab('transactions')} 
                    className="text-xs sm:text-sm p-0 h-auto flex-shrink-0"
                  >
                    {t('viewAll', language)} <ChevronRight className="w-3 h-3 sm:w-4 sm:h-4 ml-1" />
                  </Button>
                </div>
                {mockTransactions.slice(0, 3).map(transaction => (
                  <TransactionCard key={transaction.id} transaction={transaction} />
                ))}
              </div>
            </TabsContent>

            {/* Transactions Tab */}
            <TabsContent value="transactions" className="m-0 p-3 sm:p-4 space-y-4">
              <div className="flex items-center justify-between gap-2">
                <h2 className="text-lg sm:text-xl">{t('transactions', language)}</h2>
                <Badge variant="secondary" className="text-xs sm:text-sm flex-shrink-0">{mockTransactions.length} Total</Badge>
              </div>
              
              <div className="space-y-3">
                {mockTransactions.map(transaction => (
                  <TransactionCard key={transaction.id} transaction={transaction} />
                ))}
              </div>
            </TabsContent>

            {/* Security Tab */}
            <TabsContent value="security" className="m-0 p-3 sm:p-4 space-y-4 sm:space-y-6">
              <h2 className="text-lg sm:text-xl">{t('security', language)}</h2>

              {/* Security Score */}
              <Card className="p-4 sm:p-6">
                <div className="flex items-center justify-between gap-3 mb-4">
                  <div className="min-w-0 flex-1">
                    <h3 className="text-base sm:text-lg">Device Trust Score</h3>
                    <p className="text-muted-foreground text-xs sm:text-sm">Based on usage patterns</p>
                  </div>
                  <div className="text-2xl sm:text-3xl text-green-600 flex-shrink-0">{mockUser.trustScore}%</div>
                </div>
                <Progress value={mockUser.trustScore} className="h-2" />
              </Card>

              {/* Security Features */}
              <Card className="p-4 sm:p-6 space-y-4">
                <h3 className="text-base sm:text-lg">Active Security Features</h3>
                <div className="space-y-3">
                  <div className="flex items-center justify-between gap-2 p-3 rounded-lg bg-green-500/10">
                    <div className="flex items-center gap-2 sm:gap-3 min-w-0 flex-1">
                      <Shield className="w-4 h-4 sm:w-5 sm:h-5 text-green-600 flex-shrink-0" />
                      <div className="min-w-0 flex-1">
                        <p className="text-sm sm:text-base truncate">End-to-End Encryption</p>
                        <p className="text-muted-foreground text-xs sm:text-sm truncate">AES-256 + TLS 1.3</p>
                      </div>
                    </div>
                    <Badge variant="outline" className="text-green-600 border-green-600 text-xs flex-shrink-0">Active</Badge>
                  </div>
                  <div className="flex items-center justify-between gap-2 p-3 rounded-lg bg-green-500/10">
                    <div className="flex items-center gap-2 sm:gap-3 min-w-0 flex-1">
                      <Shield className="w-4 h-4 sm:w-5 sm:h-5 text-green-600 flex-shrink-0" />
                      <div className="min-w-0 flex-1">
                        <p className="text-sm sm:text-base truncate">Real-Time Fraud Detection</p>
                        <p className="text-muted-foreground text-xs sm:text-sm truncate">TinyML Model Active</p>
                      </div>
                    </div>
                    <Badge variant="outline" className="text-green-600 border-green-600 text-xs flex-shrink-0">Active</Badge>
                  </div>
                  <div className="flex items-center justify-between gap-2 p-3 rounded-lg bg-green-500/10">
                    <div className="flex items-center gap-2 sm:gap-3 min-w-0 flex-1">
                      <Shield className="w-4 h-4 sm:w-5 sm:h-5 text-green-600 flex-shrink-0" />
                      <div className="min-w-0 flex-1">
                        <p className="text-sm sm:text-base truncate">Device Binding</p>
                        <p className="text-muted-foreground text-xs sm:text-sm truncate">Unique fingerprint verified</p>
                      </div>
                    </div>
                    <Badge variant="outline" className="text-green-600 border-green-600 text-xs flex-shrink-0">Active</Badge>
                  </div>
                </div>
              </Card>

              {/* All Fraud Alerts */}
              <div className="space-y-3">
                <div className="flex items-center justify-between gap-2">
                  <h3 className="text-base sm:text-lg">{t('fraudAlerts', language)}</h3>
                  <Badge variant="destructive" className="text-xs sm:text-sm flex-shrink-0">{unresolvedAlerts.length} Unresolved</Badge>
                </div>
                {mockFraudAlerts.map(alert => (
                  <FraudAlertCard key={alert.id} alert={alert} />
                ))}
              </div>
            </TabsContent>

            {/* Profile Tab */}
            <TabsContent value="profile" className="m-0 p-3 sm:p-4 space-y-4 sm:space-y-6">
              <h2 className="text-lg sm:text-xl">Profile Settings</h2>

              <Card className="p-4 sm:p-6">
                <div className="flex items-center gap-3 sm:gap-4 mb-6">
                  <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-gradient-to-br from-blue-600 to-purple-600 flex items-center justify-center text-white text-xl sm:text-2xl flex-shrink-0">
                    {mockUser.name.charAt(0)}
                  </div>
                  <div className="min-w-0 flex-1">
                    <h3 className="text-base sm:text-lg truncate">{mockUser.name}</h3>
                    <p className="text-muted-foreground text-sm sm:text-base truncate">{mockUser.accountNumber}</p>
                  </div>
                </div>

                <div className="space-y-3 sm:space-y-4">
                  <button className="w-full flex items-center justify-between gap-2 p-3 rounded-lg bg-accent hover:bg-accent/80 transition-all active:scale-95 text-left">
                    <div className="min-w-0 flex-1">
                      <p className="text-sm sm:text-base">Language</p>
                      <p className="text-muted-foreground text-xs sm:text-sm truncate">
                        {language === 'en' && 'English'}
                        {language === 'hi' && 'हिंदी'}
                        {language === 'od' && 'ଓଡ଼ିଆ'}
                        {language === 'bn' && 'বাংলা'}
                      </p>
                    </div>
                    <div className="sm:hidden flex-shrink-0">
                      <LanguageSelector currentLanguage={language} onLanguageChange={onLanguageChange} />
                    </div>
                    <Globe className="w-4 h-4 sm:w-5 sm:h-5 hidden sm:block flex-shrink-0" />
                  </button>
                  <button className="w-full flex items-center justify-between gap-2 p-3 rounded-lg bg-accent hover:bg-accent/80 transition-all active:scale-95 text-left">
                    <div className="min-w-0 flex-1">
                      <p className="text-sm sm:text-base">Last Sync</p>
                      <p className="text-muted-foreground text-xs sm:text-sm truncate">
                        {mockUser.lastSync.toLocaleString('en-IN')}
                      </p>
                    </div>
                  </button>
                  <button className="w-full flex items-center justify-between gap-2 p-3 rounded-lg bg-accent hover:bg-accent/80 transition-all active:scale-95 text-left">
                    <div className="min-w-0 flex-1">
                      <p className="text-sm sm:text-base">Notifications</p>
                      <p className="text-muted-foreground text-xs sm:text-sm">Enabled</p>
                    </div>
                    <Bell className="w-4 h-4 sm:w-5 sm:h-5 flex-shrink-0" />
                  </button>
                </div>
              </Card>

              <Button variant="destructive" className="w-full h-11 sm:h-12 text-sm sm:text-base" onClick={onLogout}>
                Logout
              </Button>
            </TabsContent>
          </div>

          {/* Bottom Navigation */}
          <TabsList className="fixed bottom-0 left-0 right-0 grid grid-cols-4 h-14 sm:h-16 rounded-none border-t bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 safe-area-inset-bottom z-50">
            <TabsTrigger value="home" className="flex-col gap-0.5 sm:gap-1 py-1 data-[state=active]:bg-accent touch-manipulation">
              <Home className="w-4 h-4 sm:w-5 sm:h-5" />
              <span className="text-[10px] sm:text-xs leading-none">{t('dashboard', language)}</span>
            </TabsTrigger>
            <TabsTrigger value="transactions" className="flex-col gap-0.5 sm:gap-1 py-1 data-[state=active]:bg-accent touch-manipulation">
              <CreditCard className="w-4 h-4 sm:w-5 sm:h-5" />
              <span className="text-[10px] sm:text-xs leading-none">{t('transactions', language)}</span>
            </TabsTrigger>
            <TabsTrigger value="security" className="flex-col gap-0.5 sm:gap-1 py-1 data-[state=active]:bg-accent touch-manipulation">
              <Shield className="w-4 h-4 sm:w-5 sm:h-5" />
              <span className="text-[10px] sm:text-xs leading-none">{t('security', language)}</span>
            </TabsTrigger>
            <TabsTrigger value="profile" className="flex-col gap-0.5 sm:gap-1 py-1 data-[state=active]:bg-accent touch-manipulation">
              <User className="w-4 h-4 sm:w-5 sm:h-5" />
              <span className="text-[10px] sm:text-xs leading-none">Profile</span>
            </TabsTrigger>
          </TabsList>
        </Tabs>
      </div>
    </div>
  );
}