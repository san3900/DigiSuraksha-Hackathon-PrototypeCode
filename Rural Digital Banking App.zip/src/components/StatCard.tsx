import { LucideIcon } from 'lucide-react';
import { Card } from './ui/card';

interface StatCardProps {
  icon: LucideIcon;
  label: string;
  value: string | number;
  color: string;
  sublabel?: string;
}

export function StatCard({ icon: Icon, label, value, color, sublabel }: StatCardProps) {
  return (
    <Card className="p-3 sm:p-4">
      <div className="flex items-start justify-between gap-2">
        <div className="flex-1 min-w-0">
          <p className="text-muted-foreground mb-1 sm:mb-2 text-xs sm:text-sm truncate">{label}</p>
          <p className="text-xl sm:text-2xl truncate">{value}</p>
          {sublabel && (
            <p className="text-muted-foreground mt-0.5 sm:mt-1 text-xs sm:text-sm truncate">{sublabel}</p>
          )}
        </div>
        <div
          className="w-10 h-10 sm:w-12 sm:h-12 rounded-full flex items-center justify-center flex-shrink-0"
          style={{ backgroundColor: `${color}20` }}
        >
          <Icon className="w-5 h-5 sm:w-6 sm:h-6" style={{ color }} />
        </div>
      </div>
    </Card>
  );
}