import { ArrowUpRight, ArrowDownLeft, AlertTriangle } from 'lucide-react';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Transaction } from '../types';

interface TransactionCardProps {
  transaction: Transaction;
}

export function TransactionCard({ transaction }: TransactionCardProps) {
  const isDebit = transaction.type === 'debit';
  const riskColor = 
    transaction.riskScore > 70 ? 'text-red-600' :
    transaction.riskScore > 40 ? 'text-orange-600' :
    'text-green-600';

  const statusColor = 
    transaction.status === 'flagged' ? 'destructive' :
    transaction.status === 'blocked' ? 'destructive' :
    transaction.status === 'pending' ? 'secondary' :
    'default';

  return (
    <Card className="p-3 sm:p-4">
      <div className="flex items-start justify-between gap-2 sm:gap-4">
        <div className="flex items-start gap-2 sm:gap-3 flex-1 min-w-0">
          <div className={`w-8 h-8 sm:w-10 sm:h-10 rounded-full flex items-center justify-center flex-shrink-0 ${
            isDebit ? 'bg-red-500/10' : 'bg-green-500/10'
          }`}>
            {isDebit ? (
              <ArrowUpRight className="w-4 h-4 sm:w-5 sm:h-5 text-red-600" />
            ) : (
              <ArrowDownLeft className="w-4 h-4 sm:w-5 sm:h-5 text-green-600" />
            )}
          </div>
          
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-1.5 sm:gap-2">
              <p className="truncate text-sm sm:text-base">{transaction.merchant}</p>
              {transaction.status === 'flagged' && (
                <AlertTriangle className="w-3 h-3 sm:w-4 sm:h-4 text-orange-600 flex-shrink-0" />
              )}
            </div>
            <p className="text-muted-foreground text-xs sm:text-sm">
              {new Date(transaction.timestamp).toLocaleDateString('en-IN')} •{' '}
              {new Date(transaction.timestamp).toLocaleTimeString('en-IN', { 
                hour: '2-digit', 
                minute: '2-digit' 
              })}
            </p>
            {transaction.location && (
              <p className="text-muted-foreground text-xs sm:text-sm">📍 {transaction.location}</p>
            )}
          </div>
        </div>

        <div className="flex flex-col items-end gap-1 sm:gap-2 flex-shrink-0">
          <p className={`${isDebit ? 'text-red-600' : 'text-green-600'} text-sm sm:text-base whitespace-nowrap`}>
            {isDebit ? '-' : '+'} ₹{transaction.amount.toLocaleString('en-IN')}
          </p>
          <div className="flex gap-1 sm:gap-2 flex-wrap justify-end">
            {transaction.riskScore > 50 && (
              <Badge variant="outline" className={`${riskColor} text-[10px] sm:text-xs`}>
                Risk: {transaction.riskScore}
              </Badge>
            )}
            {transaction.status !== 'completed' && (
              <Badge variant={statusColor} className="text-[10px] sm:text-xs">{transaction.status}</Badge>
            )}
          </div>
        </div>
      </div>
    </Card>
  );
}