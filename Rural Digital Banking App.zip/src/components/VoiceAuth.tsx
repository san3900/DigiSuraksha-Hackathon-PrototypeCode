import { useState, useEffect } from 'react';
import { Mic, CheckCircle2, XCircle } from 'lucide-react';
import { Button } from './ui/button';
import { Language } from '../types';
import { t } from '../utils/translations';
import { motion } from 'motion/react';

interface VoiceAuthProps {
  language: Language;
  onSuccess: () => void;
  onCancel: () => void;
}

export function VoiceAuth({ language, onSuccess, onCancel }: VoiceAuthProps) {
  const [status, setStatus] = useState<'ready' | 'listening' | 'success' | 'failed'>('ready');

  const startListening = () => {
    setStatus('listening');
    // Simulate voice recognition
    setTimeout(() => {
      // 95% success rate simulation
      if (Math.random() > 0.05) {
        setStatus('success');
        setTimeout(onSuccess, 800);
      } else {
        setStatus('failed');
        setTimeout(() => setStatus('ready'), 2000);
      }
    }, 3000);
  };

  return (
    <div className="flex flex-col items-center justify-center gap-6 sm:gap-8 p-4 sm:p-8">
      <motion.div
        animate={{
          scale: status === 'listening' ? [1, 1.2, 1] : 1,
        }}
        transition={{
          duration: 1,
          repeat: status === 'listening' ? Infinity : 0,
        }}
      >
        {status === 'success' ? (
          <div className="w-24 h-24 sm:w-32 sm:h-32 rounded-full bg-green-500/20 flex items-center justify-center">
            <CheckCircle2 className="w-16 h-16 sm:w-20 sm:h-20 text-green-600" />
          </div>
        ) : status === 'failed' ? (
          <div className="w-24 h-24 sm:w-32 sm:h-32 rounded-full bg-red-500/20 flex items-center justify-center">
            <XCircle className="w-16 h-16 sm:w-20 sm:h-20 text-red-600" />
          </div>
        ) : (
          <div className="w-24 h-24 sm:w-32 sm:h-32 rounded-full bg-purple-500/20 flex items-center justify-center">
            <Mic className="w-16 h-16 sm:w-20 sm:h-20 text-purple-600" />
          </div>
        )}
      </motion.div>

      <div className="text-center space-y-2">
        <p className="text-muted-foreground text-sm sm:text-base">
          {status === 'ready' && t('speakNow', language)}
          {status === 'listening' && t('listening', language)}
          {status === 'success' && `${t('verify', language)} ✓`}
          {status === 'failed' && 'Voice Not Recognized'}
        </p>
      </div>

      <div className="flex gap-3 sm:gap-4 flex-wrap justify-center">
        {status === 'ready' && (
          <>
            <Button onClick={startListening} className="min-w-24 sm:min-w-32 h-10 sm:h-11 text-sm sm:text-base">
              {t('speakNow', language)}
            </Button>
            <Button variant="outline" onClick={onCancel} className="min-w-24 sm:min-w-32 h-10 sm:h-11 text-sm sm:text-base">
              {t('cancel', language)}
            </Button>
          </>
        )}
        {status === 'failed' && (
          <Button variant="outline" onClick={onCancel} className="min-w-24 sm:min-w-32 h-10 sm:h-11 text-sm sm:text-base">
            {t('cancel', language)}
          </Button>
        )}
      </div>
    </div>
  );
}