import { useState } from 'react';
import { Fingerprint, Mic, Lock, Shield } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from './ui/dialog';
import { AuthMethodCard } from './AuthMethodCard';
import { BiometricAuth } from './BiometricAuth';
import { VoiceAuth } from './VoiceAuth';
import { PinAuth } from './PinAuth';
import { LanguageSelector } from './LanguageSelector';
import { Language, AuthMethod } from '../types';
import { t } from '../utils/translations';

interface LoginScreenProps {
  language: Language;
  onLanguageChange: (language: Language) => void;
  onLoginSuccess: () => void;
}

export function LoginScreen({ language, onLanguageChange, onLoginSuccess }: LoginScreenProps) {
  const [selectedMethod, setSelectedMethod] = useState<AuthMethod | null>(null);

  const authMethods = [
    { method: 'biometric' as AuthMethod, icon: Fingerprint, label: t('fingerprint', language), color: '#3b82f6' },
    { method: 'voice' as AuthMethod, icon: Mic, label: t('voiceAuth', language), color: '#a855f7' },
    { method: 'pin' as AuthMethod, icon: Lock, label: t('pinAuth', language), color: '#f97316' },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white dark:from-gray-900 dark:to-gray-800 flex flex-col safe-area-inset">
      {/* Header */}
      <div className="p-3 sm:p-4 flex justify-between items-center gap-2 safe-area-inset-top">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-full bg-blue-600 flex items-center justify-center flex-shrink-0">
            <Shield className="w-4 h-4 sm:w-6 sm:h-6 text-white" />
          </div>
          <h1 className="text-base sm:text-xl">{t('appTitle', language)}</h1>
        </div>
        <LanguageSelector currentLanguage={language} onLanguageChange={onLanguageChange} />
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col items-center justify-center p-4 sm:p-6 gap-6 sm:gap-8">
        <div className="text-center space-y-1 sm:space-y-2">
          <h2 className="text-xl sm:text-2xl">{t('welcomeBack', language)}</h2>
          <p className="text-muted-foreground text-sm sm:text-base">{t('chooseAuth', language)}</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 sm:gap-4 w-full max-w-3xl">
          {authMethods.map(({ method, icon, label, color }) => (
            <AuthMethodCard
              key={method}
              icon={icon}
              label={label}
              color={color}
              onClick={() => setSelectedMethod(method)}
            />
          ))}
        </div>

        {/* Offline Indicator */}
        <div className="flex items-center gap-2 text-muted-foreground text-xs sm:text-sm">
          <div className="w-2 h-2 rounded-full bg-green-500" />
          <span>Device Trusted • Offline Mode Ready</span>
        </div>
      </div>

      {/* Auth Dialog */}
      <Dialog open={selectedMethod !== null} onOpenChange={() => setSelectedMethod(null)}>
        <DialogContent className="w-[calc(100%-2rem)] sm:max-w-md max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-base sm:text-lg">
              {selectedMethod === 'biometric' && t('fingerprint', language)}
              {selectedMethod === 'voice' && t('voiceAuth', language)}
              {selectedMethod === 'pin' && t('pinAuth', language)}
            </DialogTitle>
            <DialogDescription className="sr-only">
              {selectedMethod === 'biometric' && 'Authenticate using your fingerprint'}
              {selectedMethod === 'voice' && 'Authenticate using your voice'}
              {selectedMethod === 'pin' && 'Authenticate using your PIN'}
            </DialogDescription>
          </DialogHeader>
          {selectedMethod === 'biometric' && (
            <BiometricAuth
              language={language}
              onSuccess={onLoginSuccess}
              onCancel={() => setSelectedMethod(null)}
            />
          )}
          {selectedMethod === 'voice' && (
            <VoiceAuth
              language={language}
              onSuccess={onLoginSuccess}
              onCancel={() => setSelectedMethod(null)}
            />
          )}
          {selectedMethod === 'pin' && (
            <PinAuth
              language={language}
              onSuccess={onLoginSuccess}
              onCancel={() => setSelectedMethod(null)}
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}