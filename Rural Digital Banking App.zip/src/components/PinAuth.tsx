import { useState } from 'react';
import { Lock, Delete } from 'lucide-react';
import { Button } from './ui/button';
import { Language } from '../types';
import { t } from '../utils/translations';

interface PinAuthProps {
  language: Language;
  onSuccess: () => void;
  onCancel: () => void;
}

export function PinAuth({ language, onSuccess, onCancel }: PinAuthProps) {
  const [pin, setPin] = useState<string[]>([]);
  const [error, setError] = useState(false);

  const handleNumberClick = (num: number) => {
    if (pin.length < 6) {
      const newPin = [...pin, num.toString()];
      setPin(newPin);
      setError(false);
      
      // Auto verify when 6 digits entered
      if (newPin.length === 6) {
        setTimeout(() => {
          // Simulate PIN verification (accept any 6 digit PIN)
          onSuccess();
        }, 300);
      }
    }
  };

  const handleDelete = () => {
    setPin(pin.slice(0, -1));
    setError(false);
  };

  const numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 0];

  return (
    <div className="flex flex-col items-center justify-center gap-4 sm:gap-8 p-4 sm:p-6">
      <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-orange-500/20 flex items-center justify-center">
        <Lock className="w-8 h-8 sm:w-10 sm:h-10 text-orange-600" />
      </div>

      <div className="text-center space-y-2">
        <p className="text-sm sm:text-base">{t('enterPin', language)}</p>
      </div>

      {/* PIN Display */}
      <div className="flex gap-2 sm:gap-3">
        {[0, 1, 2, 3, 4, 5].map((i) => (
          <div
            key={i}
            className={`w-10 h-10 sm:w-12 sm:h-12 rounded-lg border-2 flex items-center justify-center transition-all ${
              pin[i]
                ? 'bg-orange-500 border-orange-500'
                : error
                ? 'border-red-500'
                : 'border-border'
            }`}
          >
            {pin[i] && <div className="w-2.5 h-2.5 sm:w-3 sm:h-3 rounded-full bg-white" />}
          </div>
        ))}
      </div>

      {error && (
        <p className="text-destructive text-sm">Incorrect PIN</p>
      )}

      {/* Number Pad */}
      <div className="grid grid-cols-3 gap-3 sm:gap-4 w-full max-w-xs">
        {numbers.slice(0, 9).map((num) => (
          <button
            key={num}
            onClick={() => handleNumberClick(num)}
            className="aspect-square rounded-xl bg-secondary hover:bg-accent text-xl sm:text-2xl active:scale-95 transition-all min-h-[56px] sm:min-h-[64px] flex items-center justify-center touch-manipulation"
            type="button"
          >
            {num}
          </button>
        ))}
        <button
          onClick={onCancel}
          className="aspect-square rounded-xl bg-destructive/10 hover:bg-destructive/20 text-destructive active:scale-95 transition-all text-xl min-h-[56px] sm:min-h-[64px] flex items-center justify-center touch-manipulation"
          type="button"
        >
          ✕
        </button>
        <button
          onClick={() => handleNumberClick(0)}
          className="aspect-square rounded-xl bg-secondary hover:bg-accent text-xl sm:text-2xl active:scale-95 transition-all min-h-[56px] sm:min-h-[64px] flex items-center justify-center touch-manipulation"
          type="button"
        >
          0
        </button>
        <button
          onClick={handleDelete}
          className="aspect-square rounded-xl bg-secondary hover:bg-accent flex items-center justify-center active:scale-95 transition-all min-h-[56px] sm:min-h-[64px] touch-manipulation"
          type="button"
        >
          <Delete className="w-5 h-5 sm:w-6 sm:h-6" />
        </button>
      </div>
    </div>
  );
}