import { useState, useEffect } from 'react';
import { Fingerprint, CheckCircle2, XCircle } from 'lucide-react';
import { Button } from './ui/button';
import { Language } from '../types';
import { t } from '../utils/translations';
import { motion } from 'motion/react';

interface BiometricAuthProps {
  language: Language;
  onSuccess: () => void;
  onCancel: () => void;
}

export function BiometricAuth({ language, onSuccess, onCancel }: BiometricAuthProps) {
  const [status, setStatus] = useState<'waiting' | 'scanning' | 'success' | 'failed'>('waiting');

  useEffect(() => {
    // Simulate biometric scanning
    const timer = setTimeout(() => {
      setStatus('scanning');
      setTimeout(() => {
        // 95% success rate simulation
        if (Math.random() > 0.05) {
          setStatus('success');
          setTimeout(onSuccess, 800);
        } else {
          setStatus('failed');
        }
      }, 2000);
    }, 500);

    return () => clearTimeout(timer);
  }, [onSuccess]);

  return (
    <div className="flex flex-col items-center justify-center gap-6 sm:gap-8 p-4 sm:p-8">
      <motion.div
        animate={{
          scale: status === 'scanning' ? [1, 1.1, 1] : 1,
        }}
        transition={{
          duration: 1.5,
          repeat: status === 'scanning' ? Infinity : 0,
        }}
        className="relative"
      >
        {status === 'success' ? (
          <div className="w-24 h-24 sm:w-32 sm:h-32 rounded-full bg-green-500/20 flex items-center justify-center">
            <CheckCircle2 className="w-16 h-16 sm:w-20 sm:h-20 text-green-600" />
          </div>
        ) : status === 'failed' ? (
          <div className="w-24 h-24 sm:w-32 sm:h-32 rounded-full bg-red-500/20 flex items-center justify-center">
            <XCircle className="w-16 h-16 sm:w-20 sm:h-20 text-red-600" />
          </div>
        ) : (
          <div className="w-24 h-24 sm:w-32 sm:h-32 rounded-full bg-blue-500/20 flex items-center justify-center">
            <Fingerprint className="w-16 h-16 sm:w-20 sm:h-20 text-blue-600" />
          </div>
        )}
      </motion.div>

      <div className="text-center space-y-2">
        <p className="text-muted-foreground text-sm sm:text-base">
          {status === 'waiting' && t('tapFingerprint', language)}
          {status === 'scanning' && `${t('verify', language)}...`}
          {status === 'success' && `${t('verify', language)} ✓`}
          {status === 'failed' && 'Authentication Failed'}
        </p>
      </div>

      {(status === 'failed' || status === 'waiting') && (
        <Button variant="outline" onClick={onCancel} className="min-w-24 sm:min-w-32 h-10 sm:h-11 text-sm sm:text-base">
          {t('cancel', language)}
        </Button>
      )}
    </div>
  );
}