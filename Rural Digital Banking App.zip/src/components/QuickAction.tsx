import { LucideIcon } from 'lucide-react';

interface QuickActionProps {
  icon: LucideIcon;
  label: string;
  color: string;
  onClick?: () => void;
  disabled?: boolean;
}

export function QuickAction({ icon: Icon, label, color, onClick, disabled = false }: QuickActionProps) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className="flex flex-col items-center gap-1.5 sm:gap-2 p-2 sm:p-4 rounded-lg sm:rounded-xl hover:bg-accent transition-all active:scale-95 min-w-0 disabled:opacity-50 disabled:cursor-not-allowed touch-manipulation"
      type="button"
    >
      <div
        className="w-10 h-10 sm:w-14 sm:h-14 rounded-full flex items-center justify-center flex-shrink-0"
        style={{ backgroundColor: `${color}20` }}
      >
        <Icon className="w-5 h-5 sm:w-7 sm:h-7" style={{ color }} />
      </div>
      <span className="text-center text-[10px] sm:text-sm leading-tight truncate w-full">{label}</span>
    </button>
  );
}