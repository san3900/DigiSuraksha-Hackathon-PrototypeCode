import { LucideIcon } from 'lucide-react';
import { Card } from './ui/card';

interface AuthMethodCardProps {
  icon: LucideIcon;
  label: string;
  onClick: () => void;
  color: string;
}

export function AuthMethodCard({ icon: Icon, label, onClick, color }: AuthMethodCardProps) {
  return (
    <Card
      className="p-6 sm:p-8 flex flex-col items-center justify-center gap-3 sm:gap-4 cursor-pointer hover:shadow-lg transition-all active:scale-95 border-2 min-h-[140px] sm:min-h-[180px] touch-manipulation"
      onClick={onClick}
      style={{ borderColor: color }}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          onClick();
        }
      }}
    >
      <div
        className="w-16 h-16 sm:w-20 sm:h-20 rounded-full flex items-center justify-center"
        style={{ backgroundColor: `${color}20` }}
      >
        <Icon className="w-8 h-8 sm:w-10 sm:h-10" style={{ color }} />
      </div>
      <span className="text-center text-sm sm:text-base">{label}</span>
    </Card>
  );
}