import { AlertTriangle, X } from 'lucide-react';
import { useState } from 'react';
import { Alert, AlertDescription } from './ui/alert';
import { Button } from './ui/button';

interface AlertBannerProps {
  message: string;
  type?: 'warning' | 'error' | 'info';
  dismissible?: boolean;
}

export function AlertBanner({ message, type = 'warning', dismissible = true }: AlertBannerProps) {
  const [isVisible, setIsVisible] = useState(true);

  if (!isVisible) return null;

  const colors = {
    warning: 'border-orange-500/50 bg-orange-500/10 text-orange-600',
    error: 'border-red-500/50 bg-red-500/10 text-red-600',
    info: 'border-blue-500/50 bg-blue-500/10 text-blue-600',
  };

  return (
    <Alert className={`${colors[type]} border-l-4 mb-4`}>
      <div className="flex items-start gap-2 sm:gap-3">
        <AlertTriangle className="w-4 h-4 sm:w-5 sm:h-5 flex-shrink-0 mt-0.5" />
        <AlertDescription className="flex-1 text-sm sm:text-base pr-8">
          {message}
        </AlertDescription>
        {dismissible && (
          <Button
            variant="ghost"
            size="icon"
            className="absolute right-2 top-2 h-6 w-6 sm:h-8 sm:w-8 opacity-70 hover:opacity-100"
            onClick={() => setIsVisible(false)}
          >
            <X className="w-3 h-3 sm:w-4 sm:h-4" />
          </Button>
        )}
      </div>
    </Alert>
  );
}
