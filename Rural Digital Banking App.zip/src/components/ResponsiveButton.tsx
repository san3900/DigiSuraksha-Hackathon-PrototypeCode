import { Button } from './ui/button';
import { ButtonHTMLAttributes, forwardRef } from 'react';
import { VariantProps } from 'class-variance-authority@0.7.1';
import { buttonVariants } from './ui/button';

interface ResponsiveButtonProps 
  extends ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  fullWidthOnMobile?: boolean;
  asChild?: boolean;
}

export const ResponsiveButton = forwardRef<HTMLButtonElement, ResponsiveButtonProps>(
  ({ fullWidthOnMobile = false, className = '', children, ...props }, ref) => {
    const mobileClass = fullWidthOnMobile ? 'w-full sm:w-auto' : '';
    
    return (
      <Button
        ref={ref}
        className={`touch-manipulation ${mobileClass} ${className}`.trim()}
        {...props}
      >
        {children}
      </Button>
    );
  }
);

ResponsiveButton.displayName = 'ResponsiveButton';
