import { Transaction, FraudAlert, User } from '../types';

export const mockUser: User = {
  name: 'राज कुमार',
  accountNumber: '****6789',
  balance: 45320,
  trustScore: 92,
  deviceBound: true,
  lastSync: new Date()
};

export const mockTransactions: Transaction[] = [
  {
    id: '1',
    amount: 500,
    type: 'debit',
    merchant: 'किराना स्टोर',
    timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000),
    status: 'completed',
    riskScore: 12,
    location: 'Same Village'
  },
  {
    id: '2',
    amount: 2000,
    type: 'credit',
    merchant: 'Salary Credit',
    timestamp: new Date(Date.now() - 24 * 60 * 60 * 1000),
    status: 'completed',
    riskScore: 5,
  },
  {
    id: '3',
    amount: 1500,
    type: 'debit',
    merchant: 'Medicine Shop',
    timestamp: new Date(Date.now() - 48 * 60 * 60 * 1000),
    status: 'completed',
    riskScore: 8,
    location: 'Nearby Town'
  },
  {
    id: '4',
    amount: 5000,
    type: 'debit',
    merchant: 'Unknown Merchant',
    timestamp: new Date(Date.now() - 1 * 60 * 60 * 1000),
    status: 'flagged',
    riskScore: 78,
    location: 'Different State'
  },
  {
    id: '5',
    amount: 300,
    type: 'debit',
    merchant: 'Mobile Recharge',
    timestamp: new Date(Date.now() - 72 * 60 * 60 * 1000),
    status: 'completed',
    riskScore: 3
  }
];

export const mockFraudAlerts: FraudAlert[] = [
  {
    id: '1',
    severity: 'high',
    message: 'Unusual transaction detected from different location',
    timestamp: new Date(Date.now() - 1 * 60 * 60 * 1000),
    transactionId: '4',
    resolved: false
  },
  {
    id: '2',
    severity: 'medium',
    message: 'Multiple login attempts detected',
    timestamp: new Date(Date.now() - 6 * 60 * 60 * 1000),
    resolved: true
  },
  {
    id: '3',
    severity: 'low',
    message: 'Device location changed',
    timestamp: new Date(Date.now() - 24 * 60 * 60 * 1000),
    resolved: true
  }
];
