import { Language, TranslationKey } from '../types';

export const translations: Record<string, TranslationKey> = {
  appTitle: {
    en: 'Secure Banking',
    hi: 'सुरक्षित बैंकिंग',
    od: 'ସୁରକ୍ଷିତ ବ୍ୟାଙ୍କିଂ',
    bn: 'সুরক্ষিত ব্যাংকিং'
  },
  welcomeBack: {
    en: 'Welcome Back',
    hi: 'स्वागत है',
    od: 'ସ୍ୱାଗତ',
    bn: 'স্বাগতম'
  },
  chooseAuth: {
    en: 'Choose Login Method',
    hi: 'लॉगिन विधि चुनें',
    od: 'ଲଗଇନ୍ ପ୍ରଣାଳୀ ବାଛନ୍ତୁ',
    bn: 'লগইন পদ্ধতি বেছে নিন'
  },
  fingerprint: {
    en: 'Fingerprint',
    hi: 'फ़िंगरप्रिंट',
    od: 'ଆଙ୍ଗୁଠି ଚିହ୍ନ',
    bn: 'আঙুলের ছাপ'
  },
  voiceAuth: {
    en: 'Voice',
    hi: 'आवाज',
    od: 'ସ୍ୱର',
    bn: 'কণ্ঠস্বর'
  },
  pinAuth: {
    en: 'PIN',
    hi: 'पिन',
    od: 'ପିନ୍',
    bn: 'পিন'
  },
  dashboard: {
    en: 'Dashboard',
    hi: 'डैशबोर्ड',
    od: 'ଡ୍ୟାସବୋର୍ଡ',
    bn: 'ড্যাশবোর্ড'
  },
  transactions: {
    en: 'Transactions',
    hi: 'लेन-देन',
    od: 'କାରବାର',
    bn: 'লেনদেন'
  },
  security: {
    en: 'Security',
    hi: 'सुरक्षा',
    od: 'ସୁରକ୍ଷା',
    bn: 'নিরাপত্তা'
  },
  balance: {
    en: 'Available Balance',
    hi: 'उपलब्ध शेष',
    od: 'ଉପଲବ୍ଧ ବାକି',
    bn: 'উপলব্ধ ব্যালেন্স'
  },
  trustScore: {
    en: 'Trust Score',
    hi: 'विश्वास स्कोर',
    od: 'ବିଶ୍ୱାସ ସ୍କୋର',
    bn: 'বিশ্বাস স্কোর'
  },
  recentTransactions: {
    en: 'Recent Transactions',
    hi: 'हालिया लेनदेन',
    od: 'ସାମ୍ପ୍ରତିକ କାରବାର',
    bn: 'সাম্প্রতিক লেনদেন'
  },
  fraudAlerts: {
    en: 'Fraud Alerts',
    hi: 'धोखाधड़ी चेतावनी',
    od: 'ଠକେଇ ସତର୍କତା',
    bn: 'প্রতারণা সতর্কতা'
  },
  sendMoney: {
    en: 'Send Money',
    hi: 'पैसे भेजें',
    od: 'ଟଙ୍କା ପଠାନ୍ତୁ',
    bn: 'টাকা পাঠান'
  },
  receiveMoney: {
    en: 'Receive',
    hi: 'प्राप्त करें',
    od: 'ଗ୍ରହଣ କରନ୍ତୁ',
    bn: 'গ্রহণ করুন'
  },
  scanQR: {
    en: 'Scan QR',
    hi: 'QR स्कैन करें',
    od: 'QR ସ୍କାନ୍ କରନ୍ତୁ',
    bn: 'QR স্ক্যান করুন'
  },
  offlineMode: {
    en: 'Offline Mode',
    hi: 'ऑफ़लाइन मोड',
    od: 'ଅଫଲାଇନ୍ ମୋଡ୍',
    bn: 'অফলাইন মোড'
  },
  syncPending: {
    en: 'Sync Pending',
    hi: 'सिंक लंबित',
    od: 'ସିଙ୍କ ବାକି',
    bn: 'সিঙ্ক অপেক্ষমাণ'
  },
  deviceTrusted: {
    en: 'Device Trusted',
    hi: 'डिवाइस विश्वसनीय',
    od: 'ଉପକରଣ ବିଶ୍ୱସ୍ତ',
    bn: 'ডিভাইস বিশ্বস্ত'
  },
  riskScore: {
    en: 'Risk Score',
    hi: 'जोखिम स्कोर',
    od: 'ବିପଦ ସ୍କୋର',
    bn: 'ঝুঁকি স্কোর'
  },
  low: {
    en: 'Low',
    hi: 'कम',
    od: 'କମ୍',
    bn: 'কম'
  },
  medium: {
    en: 'Medium',
    hi: 'मध्यम',
    od: 'ମଧ୍ୟମ',
    bn: 'মধ্যম'
  },
  high: {
    en: 'High',
    hi: 'उच्च',
    od: 'ଉଚ୍ଚ',
    bn: 'উচ্চ'
  },
  critical: {
    en: 'Critical',
    hi: 'गंभीर',
    od: 'ଗୁରୁତର',
    bn: 'সংকটজনক'
  },
  enterPin: {
    en: 'Enter Your PIN',
    hi: 'अपना पिन दर्ज करें',
    od: 'ଆପଣଙ୍କର ପିନ୍ ପ୍ରବେଶ କରନ୍ତୁ',
    bn: 'আপনার পিন লিখুন'
  },
  verify: {
    en: 'Verify',
    hi: 'सत्यापित करें',
    od: 'ଯାଞ୍ଚ କରନ୍ତୁ',
    bn: 'যাচাই করুন'
  },
  cancel: {
    en: 'Cancel',
    hi: 'रद्द करें',
    od: 'ବାତିଲ୍ କରନ୍ତୁ',
    bn: 'বাতিল করুন'
  },
  tapFingerprint: {
    en: 'Tap the fingerprint sensor',
    hi: 'फ़िंगरप्रिंट सेंसर पर टैप करें',
    od: 'ଆଙ୍ଗୁଠି ଚିହ୍ନ ସେନ୍ସର ଟ୍ୟାପ୍ କରନ୍ତୁ',
    bn: 'আঙুলের ছাপ সেন্সর টিপুন'
  },
  speakNow: {
    en: 'Speak Now',
    hi: 'अब बोलें',
    od: 'ବର୍ତ୍ତମାନ କୁହନ୍ତୁ',
    bn: 'এখন বলুন'
  },
  listening: {
    en: 'Listening...',
    hi: 'सुन रहा है...',
    od: 'ଶୁଣୁଛି...',
    bn: 'শুনছি...'
  },
  noAlerts: {
    en: 'No security alerts',
    hi: 'कोई सुरक्षा अलर्ट नहीं',
    od: 'କୌଣସି ସୁରକ୍ଷା ସତର୍କତା ନାହିଁ',
    bn: 'কোন নিরাপত্তা সতর্কতা নেই'
  },
  viewAll: {
    en: 'View All',
    hi: 'सभी देखें',
    od: 'ସମସ୍ତ ଦେଖନ୍ତୁ',
    bn: 'সব দেখুন'
  }
};

export function t(key: string, language: Language): string {
  return translations[key]?.[language] || translations[key]?.en || key;
}
