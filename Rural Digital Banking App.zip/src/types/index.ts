export type Language = 'en' | 'hi' | 'od' | 'bn';

export type AuthMethod = 'biometric' | 'voice' | 'pin';

export interface Transaction {
  id: string;
  amount: number;
  type: 'debit' | 'credit';
  merchant: string;
  timestamp: Date;
  status: 'pending' | 'completed' | 'flagged' | 'blocked';
  riskScore: number;
  location?: string;
}

export interface User {
  name: string;
  accountNumber: string;
  balance: number;
  trustScore: number;
  deviceBound: boolean;
  lastSync: Date;
}

export interface FraudAlert {
  id: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  message: string;
  timestamp: Date;
  transactionId?: string;
  resolved: boolean;
}

export interface TranslationKey {
  en: string;
  hi: string;
  od: string;
  bn: string;
}
