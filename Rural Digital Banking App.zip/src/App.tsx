import { useState } from 'react';
import { LoginScreen } from './components/LoginScreen';
import { Dashboard } from './components/Dashboard';
import { Language } from './types';

export default function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [language, setLanguage] = useState<Language>('en');

  return (
    <div className="size-full min-h-screen overflow-hidden">
      {!isAuthenticated ? (
        <LoginScreen
          language={language}
          onLanguageChange={setLanguage}
          onLoginSuccess={() => setIsAuthenticated(true)}
        />
      ) : (
        <Dashboard
          language={language}
          onLanguageChange={setLanguage}
          onLogout={() => setIsAuthenticated(false)}
        />
      )}
    </div>
  );
}