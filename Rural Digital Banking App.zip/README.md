
  # Rural Digital Banking App

  This is a code bundle for Rural Digital Banking App. The original project is available at https://www.figma.com/design/IhASsBt9hr35ak7F4r0EuT/Rural-Digital-Banking-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  